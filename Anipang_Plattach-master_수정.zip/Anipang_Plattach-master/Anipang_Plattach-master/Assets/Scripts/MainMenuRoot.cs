﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuRoot : MonoBehaviour
{
    void Start()
    {
        SoundManager.Instance.PlayMusic("bgm2", true);
    }
}
