﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Navigation : MonoBehaviour {
    public void GoToMainMenu()
    {
        SceneManager.LoadScene("mainmenu");
    }

    public void GoToGame()
    {
        SceneManager.LoadScene("main");
    }
    // 추가사항 exit 버튼
    public void Exit() 
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    } 
}
